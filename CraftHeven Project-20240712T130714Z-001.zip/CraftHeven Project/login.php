<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['submit'])){

   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);
   
   $user_type = $_POST['UserType']; // Assuming UserType is selected in the form
   $user_type = filter_var($user_type, FILTER_SANITIZE_STRING);

   $select_user_type = $conn->prepare("SELECT UserType FROM `users` WHERE Email = ?");
$select_user_type->execute([$email]);
$user_type = $select_user_type->fetch(PDO::FETCH_ASSOC)['UserType'];

   $select_user = $conn->prepare("SELECT * FROM `users` WHERE Email = ? AND Password = ? AND UserType = ?");
   $select_user->execute([$email, $pass, $user_type]);
   
   if($select_user->rowCount() > 0){
      $row = $select_user->fetch(PDO::FETCH_ASSOC);
      $_SESSION['user_id'] = $row['UserID'];
      
      if($row['UserType'] == 'Artisan'){
          header('location:./admin/dashboard.php'); // Redirect artisans to their specific page
      } else if($row['UserType'] == 'Buyer'){
          header('location:home.php'); // Redirect buyers to their specific page
      }
   } else {
      $message[] = 'Incorrect username or password!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login</title>

   <!-- Font Awesome CDN link -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="css/style1.css">

</head>
<body>
   
<!-- Header section -->
<?php include 'components/user_header.php'; ?>

<section class="form-container">
   <form action="" method="post">
      <h3>Login Now</h3>
      <input type="email" name="email" required placeholder="Enter your email" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="pass" required placeholder="Enter your password" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      
      <!-- User Type Selection -->
     <!-- <select name="UserType" class="box">
         <option value="artisan">Artisan</option>
         <option value="buyer">Buyer</option>
      </select>-->
      
      <input type="submit" value="Login Now" name="submit" class="btn">
      <p>Don't have an account? <a href="register.php">Register Now</a></p>
   </form>
</section>

<?php include 'components/footer.php'; ?>

<!-- Custom JS file link -->
<script src="js/script.js"></script>

</body>
</html>