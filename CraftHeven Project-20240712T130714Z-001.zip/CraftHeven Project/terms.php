<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/add_cart.php';

?>



<!DOCTYPE html>
<html>
<head>
  <title>Terms and Conditions</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

<!-- custom css file link  -->
<link rel="stylesheet" href="css/style.css">

  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
      padding: 30px;
    }
    h1 {
      color: #333;
    }
    p {
      color: #666;
    }
    ul {
      list-style-type: disc;
      color: #999;
    }
    li {
      margin-bottom: 10px;
    }
    a {
      color: #007bff;
      text-decoration: none;
    }
  </style>
</head>
<body>
<?php include 'components/user_header.php'; ?>
<br>
  <h1>Terms and Conditions</h1>
  <p>Welcome to our local marketplace website! By using our website, you agree to the following terms and conditions:</p>
  <ul>
    <li>You are at least 18 years old and have the legal capacity to enter into a binding agreement.</li>
    <li>You agree to provide accurate and complete information when registering for an account and using our services.</li>
    <li>You agree to abide by all applicable laws and regulations when using our website.</li>
    <li>You agree not to use our website for any illegal or unauthorized purpose.</li>
    <li>You agree to be responsible for any activity that occurs under your account.</li>
    <li>You agree to indemnify us for any damages or losses that result from your use of our website.</li>
    <li>You agree to allow us to use your information as described in our privacy policy.</li>
    <li>We reserve the right to modify these terms and conditions at any time, and your continued use of our website constitutes your acceptance of the modified terms and conditions.</li>
  </ul>


  
<?php include 'components/footer.php' ?>







<!-- custom js file link  -->
<script src="js/script.js"></script>
</body>
</html>