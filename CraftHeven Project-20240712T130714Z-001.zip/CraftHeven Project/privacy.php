<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/add_cart.php';

?>



<!DOCTYPE html>
<html>
<head>
  <title>Terms and Conditions</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

<!-- custom css file link  -->
<link rel="stylesheet" href="css/style.css">

<style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
      padding: 20px;
    }
    h1 {
      color: #333;
    }
    p {
      color: #666;
    }
    ul {
      list-style-type: disc;
      color: #999;
    }
    li {
      margin-bottom: 10px;
    }
    a {
      color: #007bff;
      text-decoration: none;
    }
  </style>
</head>
<body>
<?php include 'components/user_header.php'; ?>
  <h1>Privacy Policy</h1>
  <p>Your privacy is important to us. This Privacy Policy outlines the types of personal information we receive and collect when you use our website and how we safeguard your information.</p>
  <ul>
    <li>We may collect personal information such as your name, email address, and location when you register for an account.</li>
    <li>Your information is used to provide and improve our services, communicate with you, and personalize your experience.</li>
    <li>We may share your information with third-party service providers to facilitate our services.</li>
    <li>Your information is stored securely and we take measures to protect it from unauthorized access.</li>
    <li>We may use cookies to enhance your browsing experience on our website.</li>
    <li>By using our website, you consent to the terms of this Privacy Policy.</li>
  </ul>

  
<?php include 'components/footer.php' ?>







<!-- custom js file link  -->
<script src="js/script.js"></script>
</body>
</html>