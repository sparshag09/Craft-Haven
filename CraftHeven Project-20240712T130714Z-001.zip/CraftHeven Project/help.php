<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/add_cart.php';

?>



<!DOCTYPE html>
<html>
<head>
  <title>Terms and Conditions</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

<!-- custom css file link  -->
<link rel="stylesheet" href="css/style.css">

<style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
      padding: 20px;
    }
    h1 {
      color: #333;
    }
    p {
      color: #666;
    }
    ul {
      list-style-type: disc;
      color: #999;
    }
    li {
      margin-bottom: 10px;
    }
    a {
      color: #007bff;
      text-decoration: none;
    }
  </style>
</head>
<body>
<?php include 'components/user_header.php' ?>
  <h1>Help</h1>
  <p>We're here to help! If you have any questions or need assistance with our website, please don't hesitate to contact us.</p>
  <ul>
    <li>How do I create an account? - To create an account, click on the "Sign Up" or "Register" button and follow the prompts to enter your information.</li>
    <li>How do I add items to my cart? - Simply click on the "Add to Cart" button next to the item you wish to purchase.</li>
    <li>How do I checkout? - Go to your cart, review your items, and proceed to checkout by entering your shipping and payment information.</li>
    <li>How do I track my order? - Once your order is shipped, you will receive a tracking number via email. You can use this number to track your order.</li>
    <li>How do I change or cancel my order? - Contact customer support immediately with your order details to request changes or cancellations.</li>
    <li>How do I contact customer support? - Visit our "Contact Us" page or email us at support@example.com for assistance.</li>
  </ul>
  <p>For more information, please visit our <a href="terms.php">terms and conditions</a> and <a href="privacy.php">privacy policy</a> pages.</p>
  
<?php include 'components/footer.php' ?>







<!-- custom js file link  -->
<script src="js/script.js"></script>
</body>
</html>